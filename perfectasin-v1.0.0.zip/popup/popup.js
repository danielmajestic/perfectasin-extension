import{c as e,j as t,R as r,A as s}from"../assets/App-DD6rSx5H.js";const o=document.getElementById("root");o&&e(o).render(t.jsx(r.StrictMode,{children:t.jsx(s,{})}));
